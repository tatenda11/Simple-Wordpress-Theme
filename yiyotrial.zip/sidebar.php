<<div id="sidebar-primary" class="sidebar">
    <?php if ( is_active_sidebar( 'home_right_1' ) ) : ?>
        <?php dynamic_sidebar( 'home_right_1' ); ?>
        <!-- Time to add some widgets! -->
    <?php endif; ?>
</div>