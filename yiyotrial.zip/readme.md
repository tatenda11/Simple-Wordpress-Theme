# Wordpress Demo theme

In this task you are expected to create a custom Wordpress theme with the features
outlined below.
• A dynamic header menu with a depth of �.
• A two column widget that can be populated with a dynamic
  image in one column, and dynamic heading and subheading in
  the other column.

# Software Used

This library has a set of prerequisites that must be met for it to work

1.  Tested Theme on PHP 7.4
2.  WordPress Version 5.7.2



# Installation

1. Theme Can be uploaded to a wordpress installation see attached zip yiyo_trial.zip
2. To create the 2 column widget navigate Apperance > Widgets then drag/select Yiyo two column widget dynamic heading
3. Update fields and check frontend 


# Other Features

1. Custom website logo
2. Dynamic site title