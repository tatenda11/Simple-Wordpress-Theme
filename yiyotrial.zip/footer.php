
  <!-- ======= Footer ======= -->
  <footer id="footer mt-5">

    <div class="footer-top">
        <div class="container">
            <div class="row">
            </div>
            </div>
        </div>
    <div class="container py-4">
      <div class="copyright">
        &copy; Copyright <strong><span><?php echo get_bloginfo('name'); ?> </span></strong>. All Rights Reserved <?php echo date("Y");?>
      </div>
      <div class="credits">
        <!-- All the links in the footer should remain intact. -->
        <!-- You can delete the links only if you purchased the pro version. -->
        <!-- Licensing information: https://bootstrapmade.com/license/ -->
        <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bizland-bootstrap-business-template/ -->
        Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
      </div>
    </div>
  </footer><!-- End Footer -->
  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>

 <?php wp_footer();?>

</body>

</html>